<script type="text/html" id='_post-section'>
  <div class="container">
        <div class="row">
            <div class="col-md-8">
                <input type="text" id="container_post_search" name="container_post_search" placeholder="Search..">
                <div id="container_autocomplete_search_results"></div>
            </div>
        </div>
        <!--// Selected Videos-->
        <div class="row">
            <div class="col-sm-12">
                <h3>Selected Videos</h3>
                <div class="yac-selected-videos">
                <div class="row">
                    
                </div>
                </div><!-- // selected videos end-->
            </div>
        </div>
    </div>
</script>