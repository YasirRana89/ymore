<?php

function wm_users_update() {
    global $wpdb;
    $table_name = $wpdb->prefix . "usersdata";
    $id = $_GET["id"];
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];
//update
    if (isset($_POST['update'])) {
        $wpdb->update(
                $table_name, //table
                array('name' => $name),
                array('email' => $email),
                array('password' => $password), //data
                array('id' => $id), //where
                array('%s'),
                array('%s'),
                array('%s'), //data format
                array('%s') //where format
        );
    }
//delete
    else if (isset($_POST['delete'])) {
        $wpdb->query($wpdb->prepare("DELETE FROM $table_name WHERE id = %s", $id));
    } else {//selecting value to update	
        $users = $wpdb->get_results($wpdb->prepare("SELECT id,name,email,password from $table_name where id=%s", $id));
        
        foreach ($users as $s) {
            $id = $s->id;
            $name = $s->name;
            $email = $s->email;
            $password = $s->password;
        }

    }
    ?>
    <link type="text/css" href="<?php echo WP_PLUGIN_URL; ?>/users-crud/style-admin.css" rel="stylesheet" />
    <div class="wrap">
        <h2>USER DATA</h2>

        <?php if ($_POST['delete']) { ?>
            <div class="updated"><p>User deleted</p></div>
            <a href="<?php echo admin_url('admin.php?page=wm_users_list') ?>">&laquo; Back to schools list</a>

        <?php } else if ($_POST['update']) { ?>
            <div class="updated"><p>User updated</p></div>
            <a href="<?php echo admin_url('admin.php?page=wm_users_list') ?>">&laquo; Back to schools list</a>

        <?php } else { ?>
            <form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
                <table class='wp-list-table widefat fixed'>
                    <tr><th>ID</th><td><input type="text" name="id" value="<?php echo $id; ?>"/></td></tr>
                    <tr><th>NAME</th><td><input type="text" name="id" value="<?php echo $name; ?>"/></td></tr>
                    <tr><th>EMAIL</th><td><input type="text" name="id" value="<?php echo $email; ?>"/></td></tr>
                    <tr><th>PASSWORD</th><td><input type="text" name="id" value="<?php echo $password; ?>"/></td></tr>
                </table>
                <input type='submit' name="update" value='Save' class='button'> &nbsp;&nbsp;
                <input type='submit' name="delete" value='Delete' class='button' onclick="return confirm(' Are u sure u want to delete this')">
            </form>
        <?php } ?>

    </div>
    <?php
}