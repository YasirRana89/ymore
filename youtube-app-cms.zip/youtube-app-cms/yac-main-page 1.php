
    <html lang="en">

<head>
    <meta charset="utf-8">
    <title>Easy Shoping Templetes</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

    <!-- Bootstrap CSS File -->


    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"></script>
    <link rel="stylesheet" href="style/custome1.css">
    <script src="js/bootstrap.min.js"></script>
</head>
<style>
    img {
    vertical-align: middle;
    border-style: none;
    height: 250px;
}
.second-row {
    margin top: 20px;
    margin: 15px 0px 0px 0px;
    padding: 20px 20px 20px 20px;
}
.row {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: -15px;
    margin-left: -15px;
    padding: 20px 20px 20px 20px;
}
.card-title {
    margin-bottom: .75rem;
    color: #777171;
}
#crad-view{
    background-color: #e2e2e2;
}

* {
  box-sizing: border-box;
}

form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}


form.example button:hover {
  background: #0b7dda;
}

form.example::after {
  content: "";
  clear: both;
  display: table;
}

.btn-search-btn{
    float: left;
    width: 15%;
    padding: 10px;
    background: #2196F3;
    color: white;
    font-size: 17px;
    border: 1px solid grey;
    border-left: none;
    cursor: pointer;
}
.nav-pagination{
margin: 0px 0px 0px 15px;}
    </style>
<body>
<section id="crad-view">
          <div class="container container-search">
          <div class="row">
                    <div class="col-md-12">
                    <form class="example" action="">
                     <input type="text" placeholder="Search.." name="search">
                     <button class="btn-search-btn" type="submit">Search</button>
                  </form>

                    </div>
                </div>
          </div>




            <div class="container container coloum">
                <div class="row">
           <div class="col-md-4">
            <div class="card" style="width: 18rem;">
                    <img class="card-img-top" src="images/1.jpg" alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">Title</h5>
                      <a href="#" class="card-link">duration</a>
                    </div>
                  </div>
           </div>
           <div class="col-md-4">
           <div class="card" style="width: 18rem;">
           <img class="card-img-top" src="images/1.jpg" alt="Card image cap">
                    <div class="card-body">
                    <h5 class="card-title">Title</h5>
                      <a href="#" class="card-link">duration</a>
                    </div>
                  </div>
           </div>
           <div class="col-md-4">
           <div class="card" style="width: 18rem;">
           <img class="card-img-top" src="images/1.jpg" alt="Card image cap">
                    <div class="card-body">
                    <h5 class="card-title">Title</h5>
                      <a href="#" class="card-link">duration</a>
                    </div>
                  </div>
           </div>
            </div>

            <div class="row second-row">
           <div class="col-md-4">
           <div class="card" style="width: 18rem;">
           <img class="card-img-top" src="images/1.jpg" alt="Card image cap">
                    <div class="card-body">
                    <h5 class="card-title">Title</h5>
                      <a href="#" class="card-link">duration</a>
                    </div>
                  </div>
           </div>
           <div class="col-md-4">
           <div class="card" style="width: 18rem;">
           <img class="card-img-top" src="images/1.jpg" alt="Card image cap">
                    <div class="card-body">
                    <h5 class="card-title">Title</h5>
                      <a href="#" class="card-link">duration</a>
                    </div>
                  </div>
           </div>
           <div class="col-md-4">
           <div class="card" style="width: 18rem;">
           <img class="card-img-top" src="images/1.jpg" alt="Card image cap">
                    <div class="card-body">
                    <h5 class="card-title">Title</h5>
                      <a href="#" class="card-link">duration</a>
                    </div>
                  </div>
           </div>
            </div>
            </div>

             <div class="container">
                 <div class="row">
                     <div class="col-md-4">
                     </div>
                     <div class="col-md-4">
             <nav class="nav-pagination" aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item"><a class="page-link" href="#">Next</a></li>
  </ul>
</nav>
                     </div>
                     <div class="col-md-4">
                     </div>
                 </div>
             </div>
             </section>

</body>
<html>
</html>


